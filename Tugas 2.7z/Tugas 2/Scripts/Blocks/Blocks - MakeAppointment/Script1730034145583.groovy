import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

'step1'
WebUI.selectOptionByValue(findTestObject('Object Repository/2.Make Appointment/Page_CURA Healthcare Service/Facility'), 
    L_Blocks_Appointment, true)

//WebUI.check(findTestObject('Object Repository/2.Make Appointment/Page_CURA Healthcare Service/hospital_readmission'))
//if (L_Blocks_Apply == true) {
//    WebUI.check(findTestObject('Object Repository/6.Verification/Page_CURA Healthcare Service/ConfirmApply'))
//}
'step2'
if (L_Blocks_Apply == true) {
    WebUI.check(findTestObject('Object Repository/2.Make Appointment/Page_CURA Healthcare Service/hospital_readmission'))
}

//WebUI.click(findTestObject('Object Repository/2.Make Appointment/Page_CURA Healthcare Service/Medicaid'))
'step3'
def Healthcare_Program = L_Blocks_Program

switch (Healthcare_Program) {
    case Healthcare_Program = 'Medicare':
        println(Healthcare_Program)

        WebUI.click(findTestObject('Object Repository/2.Make Appointment/Page_CURA Healthcare Service/Medicare'))

        break
    case Healthcare_Program = 'Medicaid':
        println(Healthcare_Program)

        WebUI.click(findTestObject('Object Repository/2.Make Appointment/Page_CURA Healthcare Service/Medicaid'))

        break
    case Healthcare_Program = 'None':
        println(Healthcare_Program)

        WebUI.click(findTestObject('Object Repository/2.Make Appointment/Page_CURA Healthcare Service/None'))

        break
    default:
        println(Healthcare_Program)

        WebUI.click(findTestObject('Object Repository/2.Make Appointment/Page_CURA Healthcare Service/None'))

        break
}

'step4'
WebUI.setText(findTestObject('Object Repository/2.Make Appointment/Page_CURA Healthcare Service/VisitDate'), L_Blocks_Date)

'step5'
WebUI.click(findTestObject('Object Repository/2.Make Appointment/Page_CURA Healthcare Service/CommentBar'))

'step6'
WebUI.setText(findTestObject('Object Repository/2.Make Appointment/Page_CURA Healthcare Service/Comment'), L_Blocks_Comment)

WebUI.click(findTestObject('Object Repository/2.Make Appointment/Page_CURA Healthcare Service/button_Book Appointment'))

WebUI.delay(5)

WebUI.verifyElementVisible(findTestObject('6.Verification/Page_CURA Healthcare Service/Appointment Confirmation'), FailureHandling.STOP_ON_FAILURE)

WebUI.verifyElementText(findTestObject('6.Verification/Page_CURA Healthcare Service/ConfirmFacility'), L_Blocks_Appointment)

//WebUI.verifyElementText(findTestObject('6.Verification/Page_CURA Healthcare Service/ConfirmApply'), L_Blocks_Apply)
'step9'
if (L_Blocks_Apply == true) {
    WebUI.verifyElementText(findTestObject('6.Verification/Page_CURA Healthcare Service/ConfirmApply'), 'Yes')
} else {
    WebUI.verifyElementText(findTestObject('6.Verification/Page_CURA Healthcare Service/ConfirmApply'), 'No')
}

WebUI.verifyElementText(findTestObject('6.Verification/Page_CURA Healthcare Service/ConfirmHealthcareProgram'), L_Blocks_Program)

'step10'
switch (Healthcare_Program) {
    case Healthcare_Program = 'Medicare':
        println(Healthcare_Program)

        WebUI.verifyElementText(findTestObject('6.Verification/Page_CURA Healthcare Service/ConfirmHealthcareProgram'), 
            'Medicare')

        break
    case Healthcare_Program = 'Medicaid':
        println(Healthcare_Program)

        WebUI.verifyElementText(findTestObject('6.Verification/Page_CURA Healthcare Service/ConfirmHealthcareProgram'), 
            'Medicaid')

        break
    case Healthcare_Program = 'None':
        println(Healthcare_Program)

        WebUI.verifyElementText(findTestObject('6.Verification/Page_CURA Healthcare Service/ConfirmHealthcareProgram'), 
            'None')

        break
    default:
        println(Healthcare_Program)

        WebUI.verifyElementText(findTestObject('6.Verification/Page_CURA Healthcare Service/ConfirmHealthcareProgram'), 
            'None')

        break
}

WebUI.verifyElementText(findTestObject('6.Verification/Page_CURA Healthcare Service/ConfirmDComment'), L_Blocks_Comment)

