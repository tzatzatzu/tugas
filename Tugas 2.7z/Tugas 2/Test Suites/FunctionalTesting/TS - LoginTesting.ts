<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS - LoginTesting</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>c26e409c-25f2-45f7-8cf8-8b649735a26b</testSuiteGuid>
   <testCaseLink>
      <guid>f7c2c9ca-f78b-4d14-8466-aee13bf7db45</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Skenario/FunctionalTesting/TC-1.Login/LoginBerhasil</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>0ff08f5a-c3b9-47be-95c4-57f3a8eb5170</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/readyUse/DataLoginA1</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>0ff08f5a-c3b9-47be-95c4-57f3a8eb5170</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>L_username</value>
         <variableId>812abc14-5a20-4b9d-b67b-2cbc5adfd27a</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>0ff08f5a-c3b9-47be-95c4-57f3a8eb5170</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>L_password</value>
         <variableId>e8927cdf-f3eb-41a4-849a-d87f6891e5fb</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>0ff08f5a-c3b9-47be-95c4-57f3a8eb5170</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>L_url</value>
         <variableId>40198f2c-8b69-40b4-bee6-a42fd6cdec3e</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>42da6cb8-1afc-43f4-8163-5d690de2f36c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Skenario/FunctionalTesting/TC-1.Login/LoginGagal_WrongId</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
